import { createServerClient } from "@/lib/supabase-server"

export async function WelcomeBanner() {
  const supabase = createServerClient()

  // Get current user
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    return null
  }

  // Get user profile with more details
  const { data: profile } = await supabase
    .from("profiles")
    .select("first_name, last_name, last_login")
    .eq("id", session.user.id)
    .single()

  if (!profile) {
    return null
  }

  // Get user's recent order count
  const { count: orderCount } = await supabase
    .from("orders")
    .select("*", { count: "exact" })
    .eq("user_id", session.user.id)
    .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()) // Last 30 days

  // Get personalized recommendations based on user's order history
  const { data: recommendations } = await supabase
    .from("products")
    .select("*")
    .limit(3)
    .order("rating", { ascending: false })

  return (
    <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6 rounded-lg mb-6">
      <h1 className="text-2xl font-bold">Welcome back, {profile.first_name || "User"}! Great to see you again!</h1>
      <p className="mt-2 opacity-90">
        {orderCount > 0
          ? `You've placed ${orderCount} order${orderCount > 1 ? "s" : ""} in the last 30 days.`
          : "Browse our latest products and check out exclusive deals just for you."}
      </p>

      {recommendations && recommendations.length > 0 && (
        <div className="mt-4">
          <p className="font-medium">Recommended for you:</p>
          <div className="flex flex-wrap gap-2 mt-2">
            {recommendations.map((product) => (
              <a
                key={product.id}
                href={`/products/${product.id}`}
                className="bg-white bg-opacity-20 hover:bg-opacity-30 px-3 py-1 rounded-full text-sm transition-colors"
              >
                {product.name}
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

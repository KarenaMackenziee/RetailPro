"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { createClientClient } from "@/lib/supabase-client"
import { Star, ThumbsUp, Truck, ShieldCheck, RotateCcw } from "lucide-react"
import AddToCartButton from "@/components/add-to-cart-button"

// Define placeholder images
const PLACEHOLDER_IMAGES = {
  default: "/placeholder.svg?height=400&width=400",
  electronics: "/placeholder.svg?height=400&width=400&text=Electronics",
  headphones: "/placeholder.svg?height=400&width=400&text=Headphones",
  camera: "/placeholder.svg?height=400&width=400&text=Camera",
  phone: "/placeholder.svg?height=400&width=400&text=Phone",
  watch: "/placeholder.svg?height=400&width=400&text=Watch",
  laptop: "/placeholder.svg?height=400&width=400&text=Laptop",
}

export default function ProductDetailPage() {
  const params = useParams()
  const [product, setProduct] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [imageError, setImageError] = useState(false)
  const [reviews, setReviews] = useState<any[]>([])

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const supabase = createClientClient()
        const { data, error } = await supabase.from("products").select("*").eq("id", params.id).single()

        if (error) throw error
        if (!data) throw new Error("Product not found")

        setProduct(data)

        // Generate sample reviews
        const reviewCount = ((Number(params.id) * 17) % 50) + 5
        const sampleReviews = Array.from({ length: 3 }).map((_, i) => ({
          id: i + 1,
          author: ["Rahul S.", "Priya M.", "Amit K.", "Neha G.", "Vikram P."][i % 5],
          rating: Math.min(5, Math.max(3, Math.floor(data.rating) + (Math.random() > 0.5 ? 1 : -1))),
          date: new Date(Date.now() - (i + 1) * 7 * 24 * 60 * 60 * 1000).toISOString(),
          content: [
            "Great product! Exactly as described and arrived quickly.",
            "Very satisfied with my purchase. The quality is excellent.",
            "Good value for money. Would recommend to others.",
            "Works perfectly for my needs. Fast shipping too!",
            "Excellent product quality and customer service.",
          ][i % 5],
        }))

        setReviews(sampleReviews)
      } catch (error) {
        console.error("Error fetching product:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchProduct()
  }, [params.id])

  const handleImageError = () => {
    setImageError(true)
  }

  // Get a placeholder image based on product name
  const getPlaceholderImage = (productName: string) => {
    if (!productName) return PLACEHOLDER_IMAGES.default

    const name = productName.toLowerCase()

    if (name.includes("headphone") || name.includes("speaker") || name.includes("audio")) {
      return PLACEHOLDER_IMAGES.headphones
    } else if (name.includes("camera") || name.includes("lens")) {
      return PLACEHOLDER_IMAGES.camera
    } else if (name.includes("phone") || name.includes("mobile") || name.includes("smartphone")) {
      return PLACEHOLDER_IMAGES.phone
    } else if (name.includes("watch") || name.includes("tracker") || name.includes("fitness")) {
      return PLACEHOLDER_IMAGES.watch
    } else if (name.includes("laptop") || name.includes("computer") || name.includes("notebook")) {
      return PLACEHOLDER_IMAGES.laptop
    } else if (name.includes("electronics") || name.includes("device") || name.includes("gadget")) {
      return PLACEHOLDER_IMAGES.electronics
    }

    return PLACEHOLDER_IMAGES.default
  }

  // Render rating stars
  const renderRatingStars = (rating: number) => {
    return (
      <div className="flex items-center">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`h-5 w-5 ${i < Math.floor(rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
          />
        ))}
        <span className="ml-2 text-gray-600">{rating.toFixed(1)}</span>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center items-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gray-900"></div>
        </div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold">Product Not Found</h2>
          <p className="mt-4">The product you're looking for doesn't exist or has been removed.</p>
        </div>
      </div>
    )
  }

  // Determine image source with fallback
  const imageSource = imageError || !product.image_url ? getPlaceholderImage(product.name) : product.image_url

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="relative h-[400px] bg-gray-50 rounded-lg overflow-hidden border">
          <img
            src={imageSource || "/placeholder.svg"}
            alt={product.name}
            className="absolute inset-0 w-full h-full object-contain p-4"
            onError={handleImageError}
          />
        </div>

        <div>
          <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
          <div className="mb-2">{renderRatingStars(product.rating)}</div>
          <div className="flex items-center text-sm text-gray-500 mb-4">
            <ThumbsUp className="h-4 w-4 mr-1" />
            <span>{((Number(params.id) * 17) % 50) + 5} customer reviews</span>
          </div>
          <p className="text-2xl font-bold text-gray-900 mb-6">₹{product.price.toLocaleString("en-IN")}</p>

          <div className="mb-8">
            <h2 className="text-lg font-semibold mb-2">Description</h2>
            <p className="text-gray-600">{product.description}</p>
          </div>

          <AddToCartButton product={product} size="lg" className="w-full md:w-auto" />

          <div className="mt-8 border-t pt-6 space-y-4">
            <div className="flex items-start">
              <Truck className="h-5 w-5 mr-3 text-gray-600 mt-0.5" />
              <div>
                <h3 className="font-medium">Free Shipping</h3>
                <p className="text-sm text-gray-500">Free shipping on orders over ₹5,000</p>
              </div>
            </div>

            <div className="flex items-start">
              <ShieldCheck className="h-5 w-5 mr-3 text-gray-600 mt-0.5" />
              <div>
                <h3 className="font-medium">Secure Payment</h3>
                <p className="text-sm text-gray-500">100% secure payment processing</p>
              </div>
            </div>

            <div className="flex items-start">
              <RotateCcw className="h-5 w-5 mr-3 text-gray-600 mt-0.5" />
              <div>
                <h3 className="font-medium">Easy Returns</h3>
                <p className="text-sm text-gray-500">30-day return policy for eligible items</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews section */}
      <div className="mt-12 border-t pt-8">
        <h2 className="text-2xl font-bold mb-6">Customer Reviews</h2>

        <div className="space-y-6">
          {reviews.map((review) => (
            <div key={review.id} className="border-b pb-6">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-700 font-medium">
                    {review.author.charAt(0)}
                  </div>
                  <div className="ml-3">
                    <p className="font-medium">{review.author}</p>
                    <p className="text-sm text-gray-500">
                      {new Date(review.date).toLocaleDateString("en-IN", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                </div>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${i < review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                    />
                  ))}
                </div>
              </div>
              <p className="text-gray-600">{review.content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ShoppingBag, ShieldCheck, Users, Package } from "lucide-react"
import { redirect } from "next/navigation"

export default function HomePage() {
  redirect("/dashboard")

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-4">
            <ShoppingBag className="h-16 w-16 text-blue-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Welcome to RetailPro</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Your complete retail management solution for seamless product browsing, cart management, and order tracking.
          </p>
        </div>

        {/* Login Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-16">
          {/* User Login */}
          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Users className="h-12 w-12 text-blue-600" />
              </div>
              <CardTitle className="text-2xl text-gray-800">Customer Portal</CardTitle>
              <CardDescription className="text-gray-600">
                Browse products, manage your cart, and track your orders
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                <Link href="/login">Customer Login</Link>
              </Button>
              <Button asChild variant="outline" className="w-full">
                <Link href="/register">Create Account</Link>
              </Button>
              <div className="text-xs text-gray-400 bg-gray-50 p-2 rounded">
                <p className="font-medium">Demo Customer Account:</p>
                <p>Email: user@retailpro.com</p>
                <p>Password: user123</p>
              </div>
            </CardContent>
          </Card>

          {/* Admin Login */}
          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="text-center">
              <div className="flex items-center justify-center mb-2">
                <ShieldCheck className="h-12 w-12 text-green-600" />
              </div>
              <CardTitle className="text-2xl text-gray-800">Admin Portal</CardTitle>
              <CardDescription className="text-gray-600">
                Manage orders, products, and customer accounts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button asChild className="w-full bg-green-600 hover:bg-green-700">
                <Link href="/admin/login">Admin Login</Link>
              </Button>
              <div className="text-xs text-gray-400 bg-gray-50 p-2 rounded">
                <p className="font-medium">Demo Admin Account:</p>
                <p>Email: admin@retailpro.com</p>
                <p>Password: admin123</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <Card className="text-center">
            <CardHeader>
              <Package className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <CardTitle>Product Management</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Comprehensive product catalog with images, descriptions, and inventory management.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <ShoppingBag className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <CardTitle>Order Processing</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Seamless cart management and checkout process with real-time order tracking.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <CardTitle>Customer Management</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Complete customer portal with order history and account management features.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
